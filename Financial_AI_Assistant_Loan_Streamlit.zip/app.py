
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from pathlib import Path

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

# ============================================================
# FINANCIAL AI ASSISTANT - LOAN & RETAIL BANKING ANALYTICS
# ============================================================

st.set_page_config(
    page_title="Financial AI Assistant",
    page_icon="🏦",
    layout="wide",
)

DATA_DIR = Path(__file__).parent

# ----------------------------- Styling -----------------------
st.markdown("""
<style>
.block-container {padding-top: 1.4rem; padding-bottom: 2rem;}
.metric-card {
    border: 1px solid #e6e6e6;
    border-radius: 12px;
    padding: 12px 16px;
    background: #ffffff;
}
.small-note {color:#666; font-size:0.9rem;}
</style>
""", unsafe_allow_html=True)


# ----------------------------- Data --------------------------
@st.cache_data
def read_xlsb(filename, sheet_name=None):
    path = DATA_DIR / filename
    if not path.exists():
        return pd.DataFrame()
    return pd.read_excel(path, engine="pyxlsb", sheet_name=sheet_name)


@st.cache_data
def load_data():
    loans = read_xlsb("loans.xlsb", "loans")
    customers = read_xlsb("customers.xlsb", "customers")
    accounts = read_xlsb("accounts.xlsb", "accounts")
    transactions = read_xlsb("transactions.xlsb", "transactions")
    tickets = read_xlsb("support tickets.xlsb", "support tickets")

    if not customers.empty:
        customers["customer_since"] = pd.to_datetime(
            customers["customer_since"], unit="D", origin="1899-12-30", errors="coerce"
        )
    if not accounts.empty:
        accounts["opening_date"] = pd.to_datetime(
            accounts["opening_date"], unit="D", origin="1899-12-30", errors="coerce"
        )
    if not transactions.empty:
        transactions["transaction_date"] = pd.to_datetime(
            transactions["transaction_date"], errors="coerce"
        )
    if not tickets.empty:
        tickets["created_date"] = pd.to_datetime(
            tickets["created_date"], errors="coerce"
        )

    return loans, customers, accounts, transactions, tickets


loans, customers, accounts, transactions, tickets = load_data()

if loans.empty:
    st.error("loans.xlsb was not found. Keep the dataset in the same folder as app.py.")
    st.stop()

# Merge loan + customer information for analytics/modeling.
loan_customer = loans.merge(customers, on="customer_id", how="left")

# ------------------------- Sidebar ---------------------------
st.sidebar.title("🏦 Financial AI Assistant")
page = st.sidebar.radio(
    "Navigate",
    ["Executive Dashboard", "Loan Risk Model", "AI Assistant", "Loan Simulator", "Data Explorer"],
)

st.sidebar.divider()
st.sidebar.caption(
    "Decision-support prototype. Predictions are estimates and should not be used "
    "as the sole basis for lending decisions."
)


# ============================================================
# EXECUTIVE DASHBOARD
# ============================================================
if page == "Executive Dashboard":
    st.title("🏦 Financial AI Assistant")
    st.subheader("Loan Portfolio & Retail Banking Intelligence")
    st.write(
        "A Streamlit decision-support application for monitoring the loan book, "
        "identifying default risk, understanding customer segments, and generating "
        "actionable banking insights."
    )

    total_loans = len(loans)
    total_disbursed = loans["loan_amount"].sum()
    avg_rate = loans["interest_rate"].mean()
    default_rate = (loans["loan_status"].eq("Default").mean() * 100)
    active_amount = loans.loc[loans["loan_status"].eq("Active"), "loan_amount"].sum()

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Loan Accounts", f"{total_loans:,}")
    c2.metric("Loan Amount", f"₹{total_disbursed/1e7:.2f} Cr")
    c3.metric("Average Interest", f"{avg_rate:.2f}%")
    c4.metric("Default Rate", f"{default_rate:.2f}%")
    c5.metric("Active Portfolio", f"₹{active_amount/1e7:.2f} Cr")

    st.divider()

    # Portfolio charts
    left, right = st.columns(2)

    with left:
        status = loans["loan_status"].value_counts().reset_index()
        status.columns = ["loan_status", "count"]
        fig = px.bar(
            status,
            x="loan_status",
            y="count",
            title="Loan Status Distribution",
            text_auto=True,
        )
        st.plotly_chart(fig, use_container_width=True)

    with right:
        by_type = (
            loans.groupby("loan_type", as_index=False)
            .agg(
                loans=("loan_id", "count"),
                amount=("loan_amount", "sum"),
                avg_rate=("interest_rate", "mean"),
            )
            .sort_values("amount", ascending=False)
        )
        fig = px.bar(
            by_type,
            x="loan_type",
            y="amount",
            title="Portfolio Value by Loan Type",
            text_auto=".2s",
        )
        st.plotly_chart(fig, use_container_width=True)

    left, right = st.columns(2)

    with left:
        default_by_type = (
            loans.assign(default=(loans["loan_status"] == "Default").astype(int))
            .groupby("loan_type", as_index=False)["default"]
            .mean()
        )
        default_by_type["default_rate"] = default_by_type["default"] * 100
        fig = px.bar(
            default_by_type.sort_values("default_rate", ascending=False),
            x="loan_type",
            y="default_rate",
            title="Default Rate by Loan Type",
            labels={"default_rate": "Default Rate (%)"},
            text_auto=".2f",
        )
        st.plotly_chart(fig, use_container_width=True)

    with right:
        fig = px.scatter(
            loan_customer,
            x="annual_income",
            y="loan_amount",
            color="loan_status",
            size="interest_rate",
            hover_name="full_name",
            hover_data=["loan_type", "tenure_months", "age"],
            title="Income vs Loan Amount",
        )
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Technical & Business Insights")

    # Automatically generated descriptive insights.
    highest_default_type = default_by_type.loc[
        default_by_type["default_rate"].idxmax(), "loan_type"
    ]
    highest_default_value = default_by_type["default_rate"].max()

    largest_type = by_type.loc[by_type["amount"].idxmax(), "loan_type"]

    st.markdown(f"""
**Portfolio observations**
- The dataset contains **{total_loans:,} loan records** across **{loans['loan_type'].nunique()} loan categories**.
- **{largest_type}** has the largest portfolio value in the supplied data.
- Overall observed default rate is **{default_rate:.2f}%**.
- **{highest_default_type}** has the highest observed default rate at approximately **{highest_default_value:.2f}%**.

**Business actions**
- Prioritize early-warning monitoring for loan types with elevated default rates.
- Segment customers by income, age, occupation and loan type rather than using one portfolio-wide risk threshold.
- Use predicted probability of default to support manual underwriting and collection prioritization.
- Track interest rate, loan size and tenure together because risk is rarely explained by one variable alone.
""")

    if not accounts.empty:
        st.subheader("Retail Banking Cross-Sell View")
        account_summary = accounts.groupby("account_type", as_index=False).agg(
            customers=("customer_id", "nunique"),
            balance=("balance", "sum"),
        )
        fig = px.bar(
            account_summary,
            x="account_type",
            y="balance",
            title="Deposits / Account Balances by Account Type",
            text_auto=".2s",
        )
        st.plotly_chart(fig, use_container_width=True)


# ============================================================
# LOAN RISK MODEL
# ============================================================
elif page == "Loan Risk Model":
    st.title("🤖 Loan Default Risk Model")
    st.write(
        "The model estimates whether a loan is likely to be in the observed "
        "`Default` class. It is a prototype for risk segmentation, not a "
        "regulated credit-decision engine."
    )

    model_df = loan_customer.copy()
    model_df["default_flag"] = (model_df["loan_status"] == "Default").astype(int)

    features = [
        "loan_type", "loan_amount", "interest_rate", "tenure_months",
        "age", "gender", "city", "occupation", "annual_income", "income_category"
    ]
    features = [c for c in features if c in model_df.columns]

    X = model_df[features]
    y = model_df["default_flag"]

    cat_cols = X.select_dtypes(include=["object"]).columns.tolist()
    num_cols = [c for c in X.columns if c not in cat_cols]

    preprocess = ColumnTransformer(
        transformers=[
            (
                "num",
                Pipeline([
                    ("imputer", SimpleImputer(strategy="median"))
                ]),
                num_cols,
            ),
            (
                "cat",
                Pipeline([
                    ("imputer", SimpleImputer(strategy="most_frequent")),
                    ("encoder", OneHotEncoder(handle_unknown="ignore")),
                ]),
                cat_cols,
            ),
        ]
    )

    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=10,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )

    pipeline = Pipeline([
        ("preprocess", preprocess),
        ("model", model),
    ])

    from sklearn.model_selection import train_test_split

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    pipeline.fit(X_train, y_train)
    pred = pipeline.predict(X_test)
    prob = pipeline.predict_proba(X_test)[:, 1]

    metrics = [
        ("Accuracy", accuracy_score(y_test, pred)),
        ("Precision", precision_score(y_test, pred, zero_division=0)),
        ("Recall", recall_score(y_test, pred, zero_division=0)),
        ("F1", f1_score(y_test, pred, zero_division=0)),
        ("ROC-AUC", roc_auc_score(y_test, prob)),
    ]

    cols = st.columns(len(metrics))
    for col, (name, value) in zip(cols, metrics):
        col.metric(name, f"{value:.3f}")

    st.divider()

    cm = confusion_matrix(y_test, pred)
    cm_df = pd.DataFrame(
        cm,
        index=["Actual Non-Default", "Actual Default"],
        columns=["Predicted Non-Default", "Predicted Default"],
    )

    left, right = st.columns(2)

    with left:
        fig = px.imshow(
            cm_df,
            text_auto=True,
            title="Confusion Matrix",
            aspect="auto",
        )
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Risk Interpretation")
        st.markdown("""
- **High predicted probability:** prioritize manual review / enhanced due diligence.
- **Medium probability:** consider additional verification and monitoring.
- **Low probability:** normal underwriting workflow may be appropriate.

The threshold should be selected using business costs, regulatory requirements,
and validation on an independent dataset—not accuracy alone.
""")

    # Scored portfolio
    scored = model_df.loc[X_test.index, [
        "loan_id", "customer_id", "loan_type",
        "loan_amount", "interest_rate", "tenure_months",
        "loan_status"
    ]].copy()
    scored["default_probability"] = prob
    scored["risk_band"] = pd.cut(
        scored["default_probability"],
        bins=[-0.01, 0.20, 0.50, 1.01],
        labels=["Low", "Medium", "High"],
    )

    st.subheader("Highest-Risk Loans")
    st.dataframe(
        scored.sort_values("default_probability", ascending=False).head(25),
        use_container_width=True,
        hide_index=True,
    )

    csv = scored.to_csv(index=False).encode("utf-8")
    st.download_button(
        "Download Risk-Scored Loans",
        csv,
        "loan_risk_scores.csv",
        "text/csv",
    )


# ============================================================
# AI ASSISTANT
# ============================================================
elif page == "AI Assistant":
    st.title("💬 Financial AI Assistant")
    st.write(
        "Ask natural-language questions about the supplied loan portfolio. "
        "This version uses a transparent analytics engine rather than sending "
        "customer data to an external AI service."
    )

    # Build reusable metrics.
    default_rate = loans["loan_status"].eq("Default").mean() * 100
    active = loans[loans["loan_status"] == "Active"]
    closed = loans[loans["loan_status"] == "Closed"]
    defaults = loans[loans["loan_status"] == "Default"]

    loan_type_summary = loans.groupby("loan_type").agg(
        loans=("loan_id", "count"),
        amount=("loan_amount", "sum"),
        avg_rate=("interest_rate", "mean"),
        default_rate=("loan_status", lambda s: (s == "Default").mean() * 100),
    ).reset_index()

    st.subheader("Try a question")
    examples = [
        "What is the default rate?",
        "Which loan type has the highest default rate?",
        "What is the total loan amount?",
        "Which loan type has the largest portfolio?",
        "What is the average interest rate?",
        "How many active loans are there?",
        "Show the highest risk loan types",
    ]

    st.caption("Examples: " + " • ".join(examples))

    question = st.text_input(
        "Ask the Financial AI Assistant",
        placeholder="e.g. Which loan type has the highest default rate?",
    )

    def answer_question(q):
        q = q.lower().strip()

        if "default rate" in q and "highest" not in q:
            return (
                f"The observed default rate is **{default_rate:.2f}%** "
                f"({len(defaults):,} defaulted loans out of {len(loans):,})."
            )

        if "highest default" in q or "highest risk loan" in q:
            row = loan_type_summary.sort_values("default_rate", ascending=False).iloc[0]
            return (
                f"**{row['loan_type']}** has the highest observed default rate "
                f"at **{row['default_rate']:.2f}%**."
            )

        if "total loan" in q or "loan amount" in q:
            return (
                f"Total loan amount in the dataset is "
                f"**₹{loans['loan_amount'].sum():,.0f}** "
                f"(about ₹{loans['loan_amount'].sum()/1e7:.2f} Cr)."
            )

        if "largest portfolio" in q or "largest loan type" in q:
            row = loan_type_summary.sort_values("amount", ascending=False).iloc[0]
            return (
                f"**{row['loan_type']}** has the largest portfolio value at "
                f"**₹{row['amount']:,.0f}**."
            )

        if "average interest" in q or "interest rate" in q:
            return f"The portfolio average interest rate is **{loans['interest_rate'].mean():.2f}%**."

        if "active loan" in q:
            return f"There are **{len(active):,} active loans** in the dataset."

        if "closed loan" in q:
            return f"There are **{len(closed):,} closed loans** in the dataset."

        if "how many" in q and "loan" in q:
            return f"The dataset contains **{len(loans):,} loans**."

        if "insight" in q or "recommend" in q or "business" in q:
            row = loan_type_summary.sort_values("default_rate", ascending=False).iloc[0]
            return (
                f"Recommended focus: monitor **{row['loan_type']}** closely because "
                f"it has the highest observed default rate (**{row['default_rate']:.2f}%**). "
                "Combine risk score, customer income, loan amount and repayment behavior "
                "before taking action."
            )

        return (
            "I can answer questions about default rate, loan amount, portfolio by "
            "loan type, interest rate, active/closed loans, and risk insights. "
            "Try: **Which loan type has the highest default rate?**"
        )

    if question:
        st.chat_message("user").write(question)
        st.chat_message("assistant").markdown(answer_question(question))

    st.divider()
    st.subheader("Portfolio Snapshot")
    st.dataframe(
        loan_type_summary.sort_values("default_rate", ascending=False),
        use_container_width=True,
        hide_index=True,
    )


# ============================================================
# LOAN SIMULATOR
# ============================================================
elif page == "Loan Simulator":
    st.title("🧮 Loan Risk & Affordability Simulator")
    st.write(
        "Estimate EMI and use the trained risk model to generate a probability "
        "of default for a hypothetical application."
    )

    # Train model on the full supplied dataset for demonstration scoring.
    model_df = loan_customer.copy()
    model_df["default_flag"] = (model_df["loan_status"] == "Default").astype(int)

    features = [
        "loan_type", "loan_amount", "interest_rate", "tenure_months",
        "age", "gender", "city", "occupation", "annual_income", "income_category"
    ]
    features = [c for c in features if c in model_df.columns]

    X = model_df[features]
    y = model_df["default_flag"]

    cat_cols = X.select_dtypes(include=["object"]).columns.tolist()
    num_cols = [c for c in X.columns if c not in cat_cols]

    preprocess = ColumnTransformer([
        ("num", SimpleImputer(strategy="median"), num_cols),
        ("cat", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore"))
        ]), cat_cols)
    ])

    model = Pipeline([
        ("preprocess", preprocess),
        ("model", RandomForestClassifier(
            n_estimators=250,
            max_depth=10,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1
        ))
    ])

    model.fit(X, y)

    left, right = st.columns(2)

    with left:
        loan_type = st.selectbox("Loan Type", sorted(loans["loan_type"].unique()))
        loan_amount = st.number_input(
            "Loan Amount (₹)",
            min_value=10000.0,
            max_value=100000000.0,
            value=float(loans["loan_amount"].median()),
            step=10000.0,
        )
        interest_rate = st.number_input(
            "Interest Rate (%)",
            min_value=0.0,
            max_value=40.0,
            value=float(loans["interest_rate"].median()),
            step=0.1,
        )
        tenure = st.number_input(
            "Tenure (months)",
            min_value=3,
            max_value=360,
            value=int(loans["tenure_months"].median()),
            step=1,
        )

    with right:
        age = st.number_input("Age", 18, 90, 35)
        gender = st.selectbox("Gender", sorted(customers["gender"].dropna().unique()))
        city = st.selectbox("City", sorted(customers["city"].dropna().unique()))
        occupation = st.selectbox("Occupation", sorted(customers["occupation"].dropna().unique()))
        income = st.number_input(
            "Annual Income (₹)",
            min_value=50000.0,
            max_value=100000000.0,
            value=float(customers["annual_income"].median()),
            step=10000.0,
        )
        income_category = st.selectbox(
            "Income Category",
            sorted(customers["income_category"].dropna().unique())
        )

    if st.button("Calculate Risk & EMI", type="primary"):
        monthly_rate = interest_rate / 100 / 12
        n = tenure

        if monthly_rate == 0:
            emi = loan_amount / n
        else:
            emi = (
                loan_amount * monthly_rate * (1 + monthly_rate) ** n
                / ((1 + monthly_rate) ** n - 1)
            )

        application = pd.DataFrame([{
            "loan_type": loan_type,
            "loan_amount": loan_amount,
            "interest_rate": interest_rate,
            "tenure_months": tenure,
            "age": age,
            "gender": gender,
            "city": city,
            "occupation": occupation,
            "annual_income": income,
            "income_category": income_category,
        }])

        risk_probability = model.predict_proba(application)[:, 1][0]
        risk_band = (
            "Low" if risk_probability < 0.20
            else "Medium" if risk_probability < 0.50
            else "High"
        )

        c1, c2, c3 = st.columns(3)
        c1.metric("Estimated EMI", f"₹{emi:,.0f}")
        c2.metric("Predicted Default Probability", f"{risk_probability*100:.1f}%")
        c3.metric("Risk Band", risk_band)

        if risk_band == "High":
            st.error("High-risk indication: consider enhanced manual review.")
        elif risk_band == "Medium":
            st.warning("Medium-risk indication: consider additional verification.")
        else:
            st.success("Low-risk indication under this prototype model.")

        st.info(
            "This simulator is an analytical prototype. It does not establish "
            "creditworthiness, affordability, regulatory eligibility, or approval."
        )


# ============================================================
# DATA EXPLORER
# ============================================================
elif page == "Data Explorer":
    st.title("🔎 Data Explorer")

    dataset = st.selectbox(
        "Choose dataset",
        ["Loans", "Customers", "Accounts", "Transactions", "Support Tickets"],
    )

    data_map = {
        "Loans": loans,
        "Customers": customers,
        "Accounts": accounts,
        "Transactions": transactions,
        "Support Tickets": tickets,
    }

    selected = data_map[dataset]

    if selected.empty:
        st.warning("This dataset is not available.")
    else:
        st.write(f"Rows: **{len(selected):,}** | Columns: **{len(selected.columns)}**")
        st.dataframe(selected.head(1000), use_container_width=True)

        csv = selected.to_csv(index=False).encode("utf-8")
        st.download_button(
            f"Download {dataset} CSV",
            csv,
            f"{dataset.lower().replace(' ', '_')}.csv",
            "text/csv",
        )

        st.subheader("Data Quality")
        quality = pd.DataFrame({
            "column": selected.columns,
            "dtype": selected.dtypes.astype(str).values,
            "missing": selected.isna().sum().values,
            "unique": selected.nunique().values,
        })
        st.dataframe(quality, use_container_width=True, hide_index=True)
