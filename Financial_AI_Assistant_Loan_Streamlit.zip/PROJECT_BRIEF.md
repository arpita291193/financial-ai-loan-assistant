# Financial AI Assistant — Project Brief

## Objective
Develop an AI-assisted banking analytics application that helps loan teams understand portfolio risk,
segment customers, identify potentially high-risk loans, and explore hypothetical loan applications.

## Business value
- Faster portfolio monitoring
- Early-warning risk segmentation
- Loan-type level risk comparison
- Data-driven manual review prioritization
- Interactive management reporting
- Consistent financial Q&A over approved portfolio data

## Technical architecture
Data files → Pandas data preparation → feature engineering → Scikit-learn preprocessing →
Random Forest risk model → Streamlit dashboard/assistant/simulator.

## Key outputs
Portfolio KPIs, default-rate analysis, risk-scored loans, confusion matrix, model metrics,
natural-language portfolio Q&A, EMI calculation, and hypothetical application risk scoring.

## Recommended production roadmap
1. Validate labels and definitions with credit-risk specialists.
2. Add repayment/delinquency history and time-aware validation.
3. Calibrate PD and select thresholds using business cost.
4. Add explainability and fairness testing.
5. Introduce secure authentication and audit logs.
6. Deploy behind approved banking infrastructure.
